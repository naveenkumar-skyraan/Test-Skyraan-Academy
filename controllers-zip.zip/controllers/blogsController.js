import db from "../db.js";

/* =========================
   GET ALL BLOGS (ADMIN)
========================= */
export async function getBlogs(req, res, next) {
  try {
    const [rows] = await db.query(
      "SELECT * FROM blogs ORDER BY updated_at DESC"
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
}

/* =========================
   GET SINGLE BLOG
========================= */
export async function getBlogById(req, res, next) {
  try {
    const [rows] = await db.query(
      "SELECT * FROM blogs WHERE id = ?",
      [req.params.id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    next(err);
  }
}

/* =========================
   CREATE BLOG
========================= */
export async function createBlog(req, res, next) {
  try {
    const {
      title,
      slug,
      featured_image,
      short_description,
      content,
      read_time,
      views,
      category_id,
      tag_id,
      status,
    } = req.body;

    const normalizedStatus =
      status === "published" ? "published" : "draft";

    await db.query(
      `
      INSERT INTO blogs (
        title, slug, featured_image, short_description,
        content, read_time, views,
        category_id, tag_id, status
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        title,
        slug,
        featured_image ?? null,
        short_description ?? null,
        content ?? null,
        read_time ?? null,
        views ?? 0,
        category_id ?? null,
        tag_id ?? null,
        normalizedStatus,
      ]
    );

    res.status(201).json({ success: true });
  } catch (err) {
    next(err);
  }
}

/* =========================
   UPDATE BLOG
========================= */
export async function updateBlog(req, res, next) {
  try {
    const {
      title,
      slug,
      featured_image,
      short_description,
      content,
      read_time,
      views,
      category_id,
      tag_id,
      status,
    } = req.body;

    const normalizedStatus =
      status === "published" ? "published" : "draft";

    await db.query(
      `
      UPDATE blogs SET
        title = ?,
        slug = ?,
        featured_image = ?,
        short_description = ?,
        content = ?,
        read_time = ?,
        views = ?,
        category_id = ?,
        tag_id = ?,
        status = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
      `,
      [
        title,
        slug,
        featured_image,
        short_description,
        content,
        read_time,
        views,
        category_id,
        tag_id,
        normalizedStatus,
        req.params.id,
      ]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}

/* =========================
   DELETE BLOG (SOFT)
========================= */
export async function deleteBlog(req, res, next) {
  try {
    await db.query(
      `
      UPDATE blogs
      SET deleted_at = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
      `,
      [req.params.id]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}

/* =========================
   TOGGLE BLOG STATUS
========================= */
export async function toggleBlogStatus(req, res, next) {
  try {
    const normalizedStatus =
      req.body.status === "published" ? "published" : "draft";

    await db.query(
      `
      UPDATE blogs
      SET status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
      `,
      [normalizedStatus, req.params.id]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}
