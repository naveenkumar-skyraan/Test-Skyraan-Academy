import db from "../db.js";

/* =========================
   GET ALL COURSES (ADMIN)
   → ONLY NON-DELETED
========================= */
export const getCourses = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT *
      FROM courses
      WHERE deleted_at IS NULL
      ORDER BY updated_at DESC
    `);

    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
};

/* =========================
   GET SINGLE COURSE
   → BLOCK DELETED
========================= */
export const getCourseById = async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `
      SELECT *
      FROM courses
      WHERE id = ? AND deleted_at IS NULL
      `,
      [req.params.id]
    );

    if (!rows.length) {
      return res.status(404).json({
        success: false,
        message: "Course not found",
      });
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    next(err);
  }
};

/* =========================
   CREATE COURSE
========================= */
export const createCourse = async (req, res, next) => {
  try {
    const {
      title,
      slug,
      short_description,
      description,
      thumbnail,
      price,
      category_id,
      level_id,
      duration_id,
      discount,
      is_featured,
      popularity_score,
      status,
    } = req.body;

    const normalizedStatus =
      status === "published" ? "published" : "draft";

    await db.query(
      `
      INSERT INTO courses (
        title,
        slug,
        short_description,
        description,
        thumbnail,
        price,
        category_id,
        level_id,
        duration_id,
        discount,
        is_featured,
        popularity_score,
        status
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        title,
        slug,
        short_description ?? null,
        description ?? null,
        thumbnail ?? null,
        price ?? null,
        category_id ?? null,
        level_id ?? null,
        duration_id ?? null,
        discount ?? 0,
        is_featured ?? 0,
        popularity_score ?? 0,
        normalizedStatus,
      ]
    );

    res.status(201).json({ success: true });
  } catch (err) {
    next(err);
  }
};

/* =========================
   UPDATE COURSE
   → BLOCK DELETED
========================= */
export const updateCourse = async (req, res, next) => {
  try {
    const {
      title,
      slug,
      short_description,
      description,
      thumbnail,
      price,
      category_id,
      level_id,
      duration_id,
      discount,
      is_featured,
      popularity_score,
      status,
    } = req.body;

    const normalizedStatus =
      status === "published" ? "published" : "draft";

    await db.query(
      `
      UPDATE courses SET
        title = ?,
        slug = ?,
        short_description = ?,
        description = ?,
        thumbnail = ?,
        price = ?,
        category_id = ?,
        level_id = ?,
        duration_id = ?,
        discount = ?,
        is_featured = ?,
        popularity_score = ?,
        status = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND deleted_at IS NULL
      `,
      [
        title,
        slug,
        short_description,
        description,
        thumbnail,
        price,
        category_id,
        level_id,
        duration_id,
        discount,
        is_featured,
        popularity_score,
        normalizedStatus,
        req.params.id,
      ]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

/* =========================
   DELETE COURSE (SOFT DELETE)
========================= */
export const deleteCourse = async (req, res, next) => {
  try {
    await db.query(
      `
      UPDATE courses
      SET deleted_at = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND deleted_at IS NULL
      `,
      [req.params.id]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

/* =========================
   TOGGLE COURSE STATUS
   → BLOCK DELETED
========================= */
export const toggleCourseStatus = async (req, res, next) => {
  try {
    const normalizedStatus =
      req.body.status === "published" ? "published" : "draft";

    await db.query(
      `
      UPDATE courses
      SET status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND deleted_at IS NULL
      `,
      [normalizedStatus, req.params.id]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};
